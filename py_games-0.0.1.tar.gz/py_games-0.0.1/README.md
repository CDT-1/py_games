#py_games
##by:ZMF
### This is some games on python.
### You need: Python3.1.0, pygame, turtle-0.0.2