import time as t
s = t.sleep

def help():
    s(1)
    print("Language:zh-CN")
    s(1)
    print("hello")
    s(1)
    print("欢迎使用")
    s(1)
    print("这个包里有许多好玩的小游戏")
    s(1)
    print("都是我筛选出来的小游戏")
    s(1)
    print("在无聊的时候可以解解闷")
    s(1)
    print("我是ZMF")
    s(1)
    print("好好玩吧！")
    s(1)
    print("再见！")
    s(1)