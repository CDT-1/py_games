from . import TIC_TAC_TOE
from . import PushTheBox
from . import snake
from . import pacman
from . import maze
from . import flappy
from . import help